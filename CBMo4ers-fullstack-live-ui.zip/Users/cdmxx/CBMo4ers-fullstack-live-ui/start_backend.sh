#!/bin/bash
cd backend || exit
pip install -r requirements.txt
python app.py
